// ============================================================
// SUPABASE CONFIG - REPLACE THESE WITH YOUR REAL VALUES
// ============================================================

const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";

// Create the client (do not edit below)
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
