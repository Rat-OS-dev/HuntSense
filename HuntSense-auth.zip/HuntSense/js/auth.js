// ============================================================
// AUTH HELPERS
// ============================================================

/**
 * Convert a username into the email format we use with Supabase.
 * Example: "Ryan" → "ryan@users.huntsense.local"
 */
function usernameToEmail(username) {
  return `${username.trim().toLowerCase()}@users.huntsense.local`;
}

/**
 * Sign up a new user
 */
async function signUp(username, fullName, password) {
  const email = usernameToEmail(username);

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        username: username.trim(),
        full_name: fullName.trim()
      }
    }
  });

  return { data, error };
}

/**
 * Log in with username + password
 */
async function signIn(username, password) {
  const email = usernameToEmail(username);

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  return { data, error };
}

/**
 * Log out
 */
async function signOut() {
  const { error } = await supabase.auth.signOut();
  return { error };
}

/**
 * Get the current session (returns null if not logged in)
 */
async function getSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

/**
 * Protect a page — redirect to login if not authenticated
 */
async function requireAuth() {
  const session = await getSession();
  if (!session) {
    window.location.href = "login.html";
    return null;
  }
  return session;
}

/**
 * If already logged in, redirect away from login/signup pages
 */
async function redirectIfLoggedIn() {
  const session = await getSession();
  if (session) {
    window.location.href = "index.html";
  }
}
