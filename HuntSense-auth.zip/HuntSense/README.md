# HuntSense

Automatic match recording and AI-powered training for Hunt: Showdown.

## Current Status (v1)
- Authentication (Login / Signup)
- Protected dashboard (index.html)

## How to use these files

1. Upload all files into your GitHub repo (`Rat-OS-dev/HuntSense`) keeping the same folder structure.
2. Create a project at [supabase.com](https://supabase.com)
3. Copy your **Project URL** and **anon public key**
4. Paste them into `js/supabase-config.js`
5. Follow the **Supabase Setup** section below

## Pages
- `signup.html` — Create account (Username + Full Name + Password)
- `login.html` — Sign in with Username + Password
- `index.html` — Protected dashboard (requires login)

---

## Supabase Setup (Required)

### 1. Create a new project
Go to https://supabase.com → New Project

### 2. Get your keys
Project Settings → API
- Project URL
- anon public key

Paste both into `js/supabase-config.js`

### 3. Enable Email Auth
Authentication → Providers → Email
- Enable Email provider
- **Disable** "Confirm email" for now (so users can log in immediately without verifying)

### 4. (Optional but recommended) Allow our custom email domain
We convert usernames into emails like:  
`yourname@users.huntsense.local`

This is only used internally. Supabase accepts it fine for development.

### 5. Done
You can now open `signup.html` and create accounts.
